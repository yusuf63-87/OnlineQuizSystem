import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

public class QuizFrame extends JFrame {
    List<Question> questions = new ArrayList<>();
    int current = 0, score = 0, userId;
    char[] answers;
    JLabel questionLabel;
    JRadioButton[] options = new JRadioButton[4];
    ButtonGroup group = new ButtonGroup();
    JButton nextBtn;

    public QuizFrame(int userId) {
        this.userId = userId;
        setTitle("Quiz");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        loadQuestions();
        answers = new char[questions.size()];

        questionLabel = new JLabel();
        JPanel optionsPanel = new JPanel(new GridLayout(4, 1));
        for (int i = 0; i < 4; i++) {
            options[i] = new JRadioButton();
            group.add(options[i]);
            optionsPanel.add(options[i]);
        }

        nextBtn = new JButton("Next");
        nextBtn.addActionListener(e -> nextQuestion());

        add(questionLabel, BorderLayout.NORTH);
        add(optionsPanel, BorderLayout.CENTER);
        add(nextBtn, BorderLayout.SOUTH);

        showQuestion();

        new Timer(30000, e -> {
            JOptionPane.showMessageDialog(this, "Time's up!");
            submitQuiz();
        }).start();

        setVisible(true);
    }

    void loadQuestions() {
        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM questions ORDER BY RAND() LIMIT 5");
            while (rs.next()) {
                questions.add(new Question(
                    rs.getInt("id"),
                    rs.getString("question_text"),
                    rs.getString("option_a"),
                    rs.getString("option_b"),
                    rs.getString("option_c"),
                    rs.getString("option_d"),
                    rs.getString("correct_option").charAt(0)
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void showQuestion() {
        group.clearSelection();
        Question q = questions.get(current);
        questionLabel.setText((current + 1) + ". " + q.text);
        options[0].setText("A) " + q.a);
        options[1].setText("B) " + q.b);
        options[2].setText("C) " + q.c);
        options[3].setText("D) " + q.d);
    }

    void nextQuestion() {
        for (int i = 0; i < 4; i++) {
            if (options[i].isSelected()) {
                answers[current] = (char) ('A' + i);
                break;
            }
        }
        if (++current == questions.size()) {
            submitQuiz();
        } else {
            showQuestion();
        }
    }

    void submitQuiz() {
        for (int i = 0; i < questions.size(); i++) {
            if (answers[i] == questions.get(i).correct) {
                score++;
            }
        }
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("INSERT INTO results (user_id, score) VALUES (?, ?)");
            ps.setInt(1, userId);
            ps.setInt(2, score);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dispose();
        new ResultFrame(score, questions, answers);
    }
}
