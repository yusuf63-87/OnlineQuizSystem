import javax.swing.*;
import java.awt.*;
import java.util.*;

public class ResultFrame extends JFrame {
    public ResultFrame(int score, List<Question> questions, char[] answers) {
        setTitle("Result");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTextArea area = new JTextArea();
        area.setEditable(false);
        StringBuilder sb = new StringBuilder("Your Score: " + score + "/" + questions.size() + "\n\n");

        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            sb.append(i + 1).append(". ").append(q.text)
              .append("\nYour answer: ").append(answers[i])
              .append("\nCorrect answer: ").append(q.correct).append("\n\n");
        }

        area.setText(sb.toString());
        add(new JScrollPane(area), BorderLayout.CENTER);
        setVisible(true);
    }
}
