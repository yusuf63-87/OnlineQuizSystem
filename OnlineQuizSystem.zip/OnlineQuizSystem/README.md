# Online Quiz System

## Technologies
- Java (Swing)
- MySQL

## How to Run
1. Import `OnlineQuiz.sql` into MySQL.
2. Set your MySQL credentials in `DBConnection.java`.
3. Compile and run `Main.java`.

## Features
- Login system
- 5 random questions per quiz
- Timer-based quiz
- Results stored in DB
