CREATE DATABASE IF NOT EXISTS quiz_app;
USE quiz_app;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

INSERT INTO users (username, password) VALUES ('admin', 'admin123');

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_text TEXT NOT NULL,
    option_a VARCHAR(255),
    option_b VARCHAR(255),
    option_c VARCHAR(255),
    option_d VARCHAR(255),
    correct_option CHAR(1)
);

INSERT INTO questions (question_text, option_a, option_b, option_c, option_d, correct_option) VALUES
('What is the capital of France?', 'London', 'Berlin', 'Paris', 'Rome', 'C'),
('Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Venus', 'Jupiter', 'B'),
('What is 2 + 2?', '3', '4', '5', '6', 'B'),
('Which language is used for Android development?', 'Python', 'Java', 'Swift', 'Ruby', 'B'),
('Who wrote Hamlet?', 'Dante', 'Shakespeare', 'Homer', 'Tolstoy', 'B');
